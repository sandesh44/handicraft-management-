<?php
echo $_GET['name'].'<br>';
echo $_GET['email'];
?>