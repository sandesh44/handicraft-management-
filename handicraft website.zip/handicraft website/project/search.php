 <?php 
$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'sunway';

// Create connection
$conn =  mysqli_connect($server, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
      $search_text=$_POST['search'];
    //  echo $search_text;


$sql = "SELECT  FROM iplab WHERE concat(name,address,email,contact,message,items) LIKE '%$search_text%'";
$query = $conn->query($sql);

if ($query->num_rows > 0) {
    // output data of each row
    while($row = $query->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. $row["address"].$row["email"].$row["contact"].$row["message"].$row["items"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
    }


   ?>