#include<iostream>
using namespace std;
int main(){
    cout<<"hello";
}