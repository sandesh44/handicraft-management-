<?php
$target_dir = 'uploads/';
if(isset($_POST['submit']))
{
  $img=$target_dir . basename($_FILES["profile_pic"]["name"]);
 // echo $_FILES['profile_pic']['name'].'<br>';
 if (!empty($_FILES['profile_pic'])) {
  $path="uploads/";
  $path=$path . basename($_FILES['profile_pic']['name']);
    if (move_uploaded_file($_FILES['profile_pic']['tmp_name'],$path)) {
      echo "The file ". basename ($_FILES['profile_pic']['name']). "has been uploaded";
    }else{
      echo "There was an error uploading the file, please try again!!!!";
    }
 }
}



  // echo '<img src=".$img.'height="200" width="150"';

?>