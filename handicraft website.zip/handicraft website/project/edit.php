<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		form{
			margin: auto;
			border: 2px, solid blue;
			padding: 20px;
		}
input:hover
{
background-color: lightblue;
}
input:valid
{
background-color: lightgreen;
}
input:focus:invalid
{
border: dotted lightpink 2px;
background-color: red;
}
</style>
</head>
<body>
<?php
$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'sunway';

$conn = mysqli_connect($server, $username, $password, $dbname);

if(!$conn){
	die('Database connection error: '.myslqi_connect_error());
}

$id=$_GET['id'];
$sql="SELECT * FROM iplab WHERE id='$id'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($query);



?>
<fieldset>
	<legend> Form</legend>
<form action='update.php' method="post" enctype="maltipart/form-data">
		<label>Name:<input type="text" name=" name" required value="<?php echo $row['name'];?>"></label><br>

		<label>Email:<input type="email" name="email" required value="<?php echo $row['email'];?>"></label><br>

		<label>Address:<input type="text" name="address" required value="<?php echo $row['address'];?>"></label><br>

		

		<label>Conatct:<input type="text" name="contact" required value="<?php echo $row['conatct'];?>"></label><br>
		<label>Items:<input type="text" name="items" required value="<?php echo $row['items'];?>"></label><br>

		<label>Message:<input type="text" name="message" required value="<?php echo $row['message'];?>"></label><br>
		<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
		<input type="submit" value="submit" name="submit">
	</form>
</fieldset>
</body>

</html>