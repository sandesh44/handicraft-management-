<!DOCTYPE html>
<html>
<body>

<form action="action.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="profile_pic" id="profile_pic">
    <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>