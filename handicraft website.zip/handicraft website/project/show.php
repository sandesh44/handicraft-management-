<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1 style="color: grey;" align="center">All THE DATA ARE LOCATED IN THIS PAGE </h1>
	<table cellpadding="15" cellspacing="10" style="margin: auto;" border="2">
		<thead>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Address</th>
			<th>Contact</th>
			<th>Items</th>
			<th>Action</th>
		</thead>
	<tbody>
<?php
$server="localhost";
$username="root";
$password="";
$db="sunway";
$conn=mysqli_connect($server,$username,$password,$db);
$sql="SELECT * FROM iplab";
$query=mysqli_query($conn,$sql); 


	
	if(!$query)
	{
		die('Error:'. myslqi_error($conn));
	}

	if(mysqli_num_rows($query)>0) {


		while($rows = mysqli_fetch_assoc($query)){
			echo '<tr>';
				echo '<td>'.$rows['id'].'</td>';
				echo '<td>'.$rows['name'].'</td>';
				echo '<td>'.$rows['email'].'</td>';
				echo '<td>'.$rows['address'].'</td>';
				echo '<td>'.$rows['contact'].'</td>';
				echo '<td>'.$rows['items'].'</td>';

				
				echo '<td><a href="delete.php?id='.$rows['id'].'">Delete</a> 
				      <a href="edit.php?id='.$rows['id'].'">Edit</a>';
			echo "</tr>";
		}
	}
//header('Location: form.php');
?>
</tbody>
</table>

</body>
</html>