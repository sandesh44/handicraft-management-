<?php 
$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'sunway';

$conn = mysqli_connect($server, $username, $password, $dbname);

if(!$conn){
	die('Database connection error:'.mysqli_connect_error());
}


if(isset($_POST['submit']))
{ 
	$name =  $_POST['name'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$contact=$_POST['contact'];
	$items=$_POST['items'];
	$message = $_POST['message'];

	
	$sql = "INSERT into iplab (name,email,address,contact,items,message) VALUES('$name','$email','$address','$contact','$items','$message')";


	$query = mysqli_query($conn, $sql);
	if($query==true)
	{
	$_SESSION['message']='Data inserted.';
   }
	if(!$query)
	{
		$_SESSION['message']='Data not inserted.';
		die('Error:'. mysqli_error($conn));
	}

	// echo '<br>Successfully data inserted.<br>';
 // header('Location: show.php');
}
?>
