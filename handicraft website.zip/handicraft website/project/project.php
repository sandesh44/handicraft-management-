<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="project.css">
    <title>Hello, world!</title>
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
<meta name="robots" content="noindex, nofollow">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<style>
div.gallery {
  border: 1px solid #ccc;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

* {
  box-sizing: border-box;
}

.responsive {
  padding: 0 6px;
  float: left;
  width: 24.99999%;
}

@media only screen and (max-width: 700px) {
  .responsive {
    width: 49.99999%;
    margin: 6px 0;
  }
}

@media only screen and (max-width: 500px) {
  .responsive {
    width: 100%;
  }
}

.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
</style>
  </head>
  <body>
<?php include 'header.php' ?>
<div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active" data-interval="1000">
      <img src="/project/images/pashmina.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
          <h5>High quality Pashmina in nepal</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
    </div>
    <div class="carousel-item" data-interval="1000">
      <img src="/project/images/bamboo.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
         <center>
            <h5 style="color: black;">First slide label</h5>
          <p style="color: black;">Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
         </center>
        </div>
    </div>
    <div class="carousel-item" data-interval="1000">
      <img src="/project/images/purse.jpg" class="d-block w-100" alt="...">
      
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<br><br>
<div class="container">
  <div class="row">
  <div class="col-sm-4" style="background-color:lavender;">
      <div class="card" style="width:200px">
    <img class="card-img-top" src="/project/images/helli.jpg" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">Doma</h4>
      <p class="card-text">She has been selling the best quality Thanka for European Country with reasonable price.</p>
      <a href="#" class="btn btn-primary stretched-link">See Profile</a>
    </div>
  </div>
  </div>
  <div class="col-sm-4" style="background-color:lavender;">
      <div class="card" style="width:200px">
    <img class="card-img-top" src="/project/images/kiran.jpg" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">Krishna Rayamajhi</h4>
      <p class="card-text">He is a villager who has experience of weaving braclet from 10 years.</p>
      <a href="#" class="btn btn-primary stretched-link">See Profile</a>
    </div>
  </div>
  </div>
    <div class="col-sm-4" style="background-color:lavender;">
      <div class="card" style="width:200px">
    <img class="card-img-top" src="/project/images/riya.jpg" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">Chitrakumari</h4>
      <p class="card-text">Chitrakumari has been passed down the experiences of weaving basket from generations.</p>
      <a href="#" class="btn btn-primary stretched-link">See Profile</a>
    </div>
  </div>
  </div>
</div>
</div><br><br>
<center>
  <div class="Gmail" style="border: solid; padding: 20px; margin: 5px;">
  <h2>Gmail SMTP</h2>
  <a href="gmail.php"><input type="submit" name="submit" class="btn btn-danger" value="Send Mail"></a>
</div>
</center>

 
<center>
<h2>HANDICRAFT PRODUCTS</h2>
</center>


<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="/project/images/braclet.jpg">
      <img src="/project/images/braclet.jpg" alt="Cinque Terre" width="600" height="400">
    </a>
    <center><div class="desc">Price: Nrs 400</div></center>
  </div>
</div>


<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="img_forest.jpg">
      <img src="/project/images/kami.jpg" alt="Forest" width="600" height="400">
    </a>
   <center> <div class="desc">Price: Nrs 1500</div></center>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="img_lights.jpg">
      <img src="/project/images/basket.jpg" alt="Northern Lights" width="600" height="400">
    </a>
   <center> <div class="desc">Price:Nrs 600</div></center>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="img_mountains.jpg">
      <img src="/project/images/peakcock.jpg" alt="Mountains" width="600" height="400">
    </a>
   <center><div class="desc">Price: Nrs 1300</div></center>
  </div>
</div>

<div class="clearfix"></div>

<div style="padding:6px;">

</div>
<div class="container">
  <div class="row">
    <div class="col-sm-6">
      <img src="/project/images/wood.jpg" width="450px">

    </div>
    <div class="col-sm-4">
      <h2>How It Is Made</h2>
      <p>Where does it come from?
Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
    </div>
  </div>
</div>

<br><br>
<center><p>YOU CAN FIND SEARCH ITEM HERE</p>
</center>
<center>
  <div class="search_1">
<?php 
$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'sunway';

// Create connection
$conn =  mysqli_connect($server, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
      $search_text=$_POST['search'];
     //echo $search_text;


$sql = "SELECT * FROM iplab WHERE concat(name,address,email,contact,message,items) LIKE '%$search_text%'";
$query = $conn->query($sql);

if ($query->num_rows > 0) {
    // output data of each row
    while($row = $query->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. $row["address"].$row["email"].$row["contact"].$row["message"].$row["items"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
    }


   ?>
</div>
</center>
<br><br>
<footer class="page-footer font-small blue-grey lighten-5">

  <div style="background-color: #21d192;">
    <div class="container">

      <!-- Grid row-->
      <div class="row py-4 d-flex align-items-center">

        <!-- Grid column -->
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h6 class="mb-0">Get connected with us on social networks!</h6>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-7 text-center text-md-right">

          <!-- Facebook -->
          <a class="fb-ic" href="https:www.facebook.com">
            <i class="fab fa-facebook-f white-text mr-4"> </i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic" href="https:www.twitter.com">
            <i class="fab fa-twitter white-text mr-4"> </i>
          </a>
          <!-- Google +-->
          <a class="gplus-ic" href="https:www.google.com">
            <i class="fab fa-google-plus-g white-text mr-4"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic" href="https:www.linkedin.com">
            <i class="fab fa-linkedin-in white-text mr-4"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic" href="https:www.instagram.com">
            <i class="fab fa-instagram white-text"> </i>
          </a>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row-->

    </div>
  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5">

    <!-- Grid row -->
    <div class="row mt-3 dark-grey-text">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold">Handicraft</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>we are the official dealer of handicraft, sclupture, idols and 
        thanka in nepal. if you required any handicraft you can contact us.</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Products</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a class="dark-grey-text" href="#!">idols</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">thanka</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">sclupture</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">handicraft</a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Useful links</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a class="dark-grey-text" href="#!">Your Account</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">Become an Affiliate</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">Shipping Rates</a>
        </p>
        <p>
          <a class="dark-grey-text" href="#!">Help</a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Contact</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <i class="fas fa-home mr-3"></i> Nepal, KTM 42600, local</p>
        <p>
          <i class="fas fa-envelope mr-3"></i> info@example.com</p>
        <p>
          <i class="fas fa-phone mr-3"></i> +977 9823456788</p>
        <p>
          <i class="fas fa-print mr-3"></i> + 977 9823456789</p>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center text-black-50 py-3">© 2018 Copyright
  </div>
  <!-- Copyright -->

</footer>
<script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" data-cfasync="false"></script>
<script>
window.cookieconsent.initialise({
  "palette": {
    "popup": {
      "background": "#000"
    },
    "button": {
      "background": "#f1d600"
    }
  },
  "theme": "classic",
  "position": "bottom"
});
</script>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>